


public class TestPerson {

	public static void main(String[] args) {
		
		Person p1 = new Person();
		
		Person p2 = new Person(" ","Bharathi",'F');
	
		
		
		String fullName;
		
			try 
		{
			if(p2.getFirstName().compareTo(" ")== 0 || p2.getLastName().compareTo(" ")==0)
			{
				throw new ExceptionIncompleteName("Please enter first name and last name");
			}
			else{
				System.out.println("Person Details:");
				System.out.println("---------------------------");
				fullName = p2.getFirstName() +" "+ p2.getLastName();
				System.out.println("Full Name: "+fullName);
				System.out.println("Gender: "+p2.getGender());
			}
			
		} 
		catch (ExceptionIncompleteName nm) 
		{
			System.out.println("Name is incomplete!");
			System.out.println(nm);
		}
			finally{
				System.out.println("End of code");
			}
		
	}

}
