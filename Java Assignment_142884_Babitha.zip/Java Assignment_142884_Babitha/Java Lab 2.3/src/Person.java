
public class Person {

	private String firstName;
	private String lastName;
	private char gender;
	
	//Getters
	public String getFirstName(){
		return this.firstName;
	}
	public String getLastName(){
		return this.lastName;
	}
	public char getGender(){
		return this.gender;
	}
	
	//Setters
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public void setGender(char gender){
		this.gender = gender;
	}
	
	public Person() {
		this.firstName = null;
		this.lastName = null;
		this.gender = ' ';
	}
	
	public Person(String firstName, String lastName, char gender) {
		setLastName(lastName);
		setFirstName(firstName);
		setGender(gender);
	}
}
