import java.util.Scanner;
enum Gender
{
	Male('M'),Female('F');
	private final char value;
	
	private Gender(char value)
	{
		this.value = value;
	}
	public char value()
	{
		return value;
	}
}
public class TestPerson {

	public static void main(String[] args) {
		Gender empGen = Gender.Female;
		long phoneno;
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Phone Number: ");
		phoneno = s.nextLong();
					
		Person p2 = new Person("Divya","Bharathi",empGen.value(),phoneno);
	    p2.dispPersonDetails();
					


	}

}
