/*2.1 Write a java program to print person details in the format as shown :*/
public class Person {

	private String 	perFirstName;
	private String 	perLastName;
	private float 	perWeight;
	private char 	perGender;
	private int		perAge;
	
	public Person(String perFName, String perLName , float perWt, char perGen, int age)
	{
		perFirstName= perFName;
		perLastName	= perLName;
		perWeight	= perWt;
		perGender	= perGen;
		perAge		= age;
	}
	
	public void dispPerDetails()
	{
		System.out.println("Person Details:");
		System.out.println("___________________________");
		System.out.println("First Name: "+perFirstName);
		System.out.println("Last Name: "+perLastName);
		System.out.println("Gender: "+perGender);
		System.out.println("Age: "+perAge);
		System.out.println("Weight: "+perWeight);
		System.out.println();
	}
	
	public static void main(String[] args) {
		Person per = new Person("Divya","Bharathi",85.55F,'F',20);
		per.dispPerDetails();

	}

}
