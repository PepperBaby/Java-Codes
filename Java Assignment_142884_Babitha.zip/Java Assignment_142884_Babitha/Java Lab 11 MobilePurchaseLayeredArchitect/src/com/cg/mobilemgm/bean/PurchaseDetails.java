package com.cg.mobilemgm.bean;

import java.sql.Date;

public class PurchaseDetails {
	private int purId;
	private String custName;
	private String custEmail;
	private String custPhoneNo;
	private Mobiles mobDetail;
	private long temp = System.currentTimeMillis();
	private java.sql.Date purDate = new java.sql.Date(temp);
	
	public int getPurId() {
		return purId;
	}
	public void setPurId(int purId) {
		this.purId = purId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public java.sql.Date getPurDate() {
		return purDate;
	}
	public void setPurDate(java.sql.Date purDate) {
		this.purDate = purDate;
	}
	public Mobiles getMobDetail() {
		return mobDetail;
	}
	public void setMobDetail(Mobiles mobDetail) {
		this.mobDetail = mobDetail;
	}
	public PurchaseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PurchaseDetails(int purId, String custName, String custEmail, Date purDate,
			String custPhoneNo, Mobiles mobDetail) {
		super();
		this.purId = purId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.custPhoneNo = custPhoneNo;
		this.mobDetail = mobDetail;
		this.purDate = purDate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purId=" + purId + ", custName=" + custName
				+ ", custEmail=" + custEmail + ", custPhoneNo=" + custPhoneNo
				+ ", mobDetail=" + mobDetail.toString() + ", purDate=" + purDate + "]";
	}
	
	
	
	
	
}
