package com.cg.mobilemgm.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;




import com.cg.mobilemgm.bean.Mobiles;
import com.cg.mobilemgm.bean.PurchaseDetails;
import com.cg.mobilemgm.exception.MobileException;
import com.cg.mobilemgm.util.DBUtil;

public class MobileDaoImpl implements MobileDao{

	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public ArrayList<Mobiles> searchMob(float minValue, float maxValue) throws MobileException {
		
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String searchQry = "SELECT * FROM mobiles WHERE price between ? and ?";
		Mobiles m = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(searchQry);
			pst.setFloat(1, minValue);
			pst.setFloat(2, maxValue);
			rs = pst.executeQuery();
			
			while(rs.next())
			{
				m = new Mobiles(rs.getInt("mobileid"),
						rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(m);
			}
			
		}
		catch (IOException | SQLException e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
		}
	
	@Override
	public int addMob(Mobiles mob) throws MobileException {
		String insertQry = "INSERT INTO mobile(mobileid,name,price,quantity) VALUES(?,?,?,?)";
		int dataAdded;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, mob.getMobileId());
			pst.setString(2, mob.getMobileName());
			pst.setFloat(3, mob.getMobilePrice());
			pst.setInt(4, mob.getMobileQuantity());

			dataAdded =pst.executeUpdate();
		} 
		catch (IOException | SQLException e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
		
	}

	@Override
	public int updateMob(Mobiles mob) throws MobileException {
		int dataUpdated;
		String updateQry = "UPDATE mobiles SET quantity = quantity - ? WHERE  mobileid = ?";
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1, mob.getMobileQuantity());
			pst.setInt(2, mob.getMobileId());
			dataUpdated =pst.executeUpdate();
		} 
		catch (IOException | SQLException e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataUpdated;
	}

	@Override
	public ArrayList<Mobiles> getAllMob() throws MobileException {
		ArrayList<Mobiles> mobList = new ArrayList<Mobiles>();
		String selectQry = "SELECT * FROM mobiles";
		Mobiles m = null;
		try 
		{
			con=DBUtil.getCon();
			st= con.createStatement();
			rs= st.executeQuery(selectQry);
			while(rs.next())
			{
				m = new Mobiles(rs.getInt("mobileid"),
						rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(m);
			}
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
	}


	

	@Override
	public int addPurDetails(PurchaseDetails pur,Mobiles mob) throws MobileException {
		String insertQry = "INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(?, ?, ?, ?, ?, ?)";
		int dataAdded;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generatePurId());
			pst.setString(2, pur.getCustName());
			pst.setString(3, pur.getCustEmail());
			pst.setString(4, pur.getCustPhoneNo());
			pst.setDate(5, pur.getPurDate());
			pst.setInt(6, mob.getMobileId());
			dataAdded =pst.executeUpdate();
		} 
		catch (IOException | SQLException e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
		
	}

	@Override
	public int generatePurId() throws MobileException {
		String qry = "SELECT pur_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try
		{
			con = DBUtil.getCon();
			st = con.createStatement();
			rs = st.executeQuery(qry);
			rs.next();
			generatedVal = rs.getInt(1);
		} 
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public ArrayList<Integer> getAllMobId() throws MobileException {
		
		ArrayList<Integer> mobIdList = new ArrayList<Integer>();
		String selectQry = "SELECT mobileid FROM mobiles";
		Mobiles m = null;
		try 
		{
			con=DBUtil.getCon();
			st= con.createStatement();
			rs= st.executeQuery(selectQry);
			while(rs.next())
			{
				int id = rs.getInt("mobileid");
				mobIdList.add(id);
			}
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mobIdList;
	}

	@Override
	public int getMobQuan(Mobiles mob) throws MobileException {
		String selectQry = "SELECT quantity FROM mobiles WHERE mobileid=?";
		int data;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setInt(1, mob.getMobileId());
			rs = pst.executeQuery();
			rs.next();
			
			data = rs.getInt("quantity");
			
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
		}
		return data;
	}

	@Override
	public int deleteMobDetails(Mobiles mob) throws MobileException {
		String deleteQry = "DELETE FROM mobiles WHERE mobileid = ?";
		int dataDeleted;
		try 
		{
			con=DBUtil.getCon();
			pst = con.prepareStatement(deleteQry);
			pst.setInt(1, mob.getMobileId());			
			dataDeleted = pst.executeUpdate();
		} 
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
		
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new MobileException(e.getMessage());
			}
			
		}
		return dataDeleted;
	}

}
