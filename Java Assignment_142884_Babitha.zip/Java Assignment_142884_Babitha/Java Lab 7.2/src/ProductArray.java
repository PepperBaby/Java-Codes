import java.util.ArrayList;

import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;


public class ProductArray {

	public static void main(String[] args) {

		ArrayList<String> Str =  new ArrayList<String>(); 

		//sorted here
		String i1 = new String("Ponds");  //boxing
		String i2 = new String("Spinx");
		String i3 = new String("Engaged"); 
		String i4 = new String("WildStone");


		//Sorted and unique
		Str.add(i1);
		Str.add(i2);
		Str.add(i3);
		Str.add(i4);


		System.out.println("*********before sorting*********** ");
		System.out.println(Str);

		System.out.println("****************After sorting***********");
		Collections.sort(Str);
		for(String tempSet:Str)
		{
			System.out.println(tempSet);
		}

	}

}
