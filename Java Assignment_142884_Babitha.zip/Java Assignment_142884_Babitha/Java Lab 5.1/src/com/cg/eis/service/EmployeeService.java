package com.cg.eis.service;

public interface EmployeeService {

	String getInsuranceScheme();
	
}
