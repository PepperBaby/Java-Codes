
public class ExceptionAgeLimit extends Exception {

	
		public ExceptionAgeLimit(String msg)
		{
			super(msg);
		}

	

}