import java.util.Scanner;


public class TestAgeLimitException {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Age of Smith");
		float Age = sc.nextInt();
		System.out.println("Enter Age of Kathy");
		float Age1 = sc.nextInt();
		
		try
		{
			if((Age <=15) || (Age1 <=15))
			{
				throw new ExceptionAgeLimit("Person age should be above 15.");
			}
			else
			{
				Person smith = new Person("Smith",Age);
				CurrentAcc c1 = new CurrentAcc(smith,(long)(Math.random()*100000),2000);
			
				c1.deposit(2000);
				
				Person kathy = new Person("Kathy",Age1);
				SavingsAcc s2 = new SavingsAcc(kathy,(long)(Math.random()*100000),3000);
				
				s2.withdraw(2000);
			
				System.out.println("Smith Details: "+c1);
				System.out.println("Current balance of Smith: "+ c1.getBalance());
				System.out.println("\nKathy Details: "+s2);
				System.out.println("Current balance of Kathy: "+ s2.getBalance());

				System.out.println("\nCurrent Result after withdraw of 3000.");
				c1.withdraw(3000);
				System.out.println("Smith Details: "+c1);
				System.out.println("Current balance of Smith: "+ c1.getBalance());
				
				System.out.println("\nSaving Result after withdraw of 600 from 1000 balance.");
				s2.withdraw(600);
				System.out.println("Kathy Details: "+s2);
				System.out.println("Current balance of Kathy: "+ s2.getBalance());
			}
		}
		catch(ExceptionAgeLimit ag)
		{
			System.out.println("Age limit not followed");
			System.out.println(ag);
		}
		finally
		{
			System.out.println("Code Ended.");
		}
		
		
		
		
	}

}
