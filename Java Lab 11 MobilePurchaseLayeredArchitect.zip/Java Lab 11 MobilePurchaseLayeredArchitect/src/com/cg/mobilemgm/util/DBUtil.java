package com.cg.mobilemgm.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mobilemgm.exception.MobileException;

public class DBUtil 
{
	static String dbunm = null;
	static String dbpwd = null;
	static String url = null;
	

	public static Connection getCon() 
			throws IOException,MobileException,SQLException
	{
		Connection con = null;
		Properties dbInfoProps = DBUtil.getProp();
		url = dbInfoProps.getProperty("dbURL");
		dbunm = dbInfoProps.getProperty("dbUser");
		dbpwd = dbInfoProps.getProperty("dbPws");
		if(con==null)
		{
			con = DriverManager.getConnection(url,dbunm,dbpwd);
		}
		return con;
	}

	public static Properties getProp() 
			throws IOException,MobileException
	{
		Properties props = new Properties();
		FileReader fr = null;

		fr = new FileReader("resources/dbInfo.properties");
		props.load(fr);

		return props;
	}
}
